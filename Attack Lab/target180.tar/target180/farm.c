/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_241(unsigned *p)
{
    *p = 3347662959U;
}

unsigned getval_399()
{
    return 2425387256U;
}

unsigned addval_461(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_393()
{
    return 3284642120U;
}

void setval_427(unsigned *p)
{
    *p = 1170444376U;
}

void setval_410(unsigned *p)
{
    *p = 2425444419U;
}

unsigned addval_380(unsigned x)
{
    return x + 2462550344U;
}

void setval_288(unsigned *p)
{
    *p = 1488667634U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_298(unsigned *p)
{
    *p = 2463205670U;
}

unsigned getval_194()
{
    return 2425471625U;
}

unsigned getval_353()
{
    return 3286272328U;
}

unsigned addval_321(unsigned x)
{
    return x + 3531919049U;
}

void setval_479(unsigned *p)
{
    *p = 3523789465U;
}

void setval_172(unsigned *p)
{
    *p = 3221799577U;
}

unsigned addval_472(unsigned x)
{
    return x + 3682914689U;
}

void setval_274(unsigned *p)
{
    *p = 3223900553U;
}

unsigned getval_113()
{
    return 3674784265U;
}

void setval_144(unsigned *p)
{
    *p = 3247492745U;
}

unsigned addval_351(unsigned x)
{
    return x + 3380924041U;
}

unsigned addval_433(unsigned x)
{
    return x + 3223375489U;
}

unsigned addval_290(unsigned x)
{
    return x + 3269495112U;
}

void setval_277(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_381()
{
    return 3269495112U;
}

unsigned getval_291()
{
    return 3374370473U;
}

unsigned addval_371(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_331()
{
    return 3375419017U;
}

unsigned getval_295()
{
    return 3229926025U;
}

unsigned getval_341()
{
    return 2429655369U;
}

unsigned getval_415()
{
    return 3676357257U;
}

unsigned getval_449()
{
    return 3267529107U;
}

unsigned addval_492(unsigned x)
{
    return x + 3269495112U;
}

void setval_106(unsigned *p)
{
    *p = 3221803401U;
}

unsigned getval_337()
{
    return 3285092784U;
}

void setval_285(unsigned *p)
{
    *p = 3385118345U;
}

unsigned getval_453()
{
    return 3223376297U;
}

unsigned addval_488(unsigned x)
{
    return x + 2425668233U;
}

unsigned getval_421()
{
    return 2429651376U;
}

void setval_359(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_231()
{
    return 2497743176U;
}

unsigned getval_481()
{
    return 3225997705U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
